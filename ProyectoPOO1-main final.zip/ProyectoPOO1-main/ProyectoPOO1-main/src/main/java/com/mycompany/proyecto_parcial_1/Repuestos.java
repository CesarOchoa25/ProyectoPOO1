package com.mycompany.proyecto_parcial_1;

public abstract class Repuestos {
    //Atributos de la clase de los repuestos encapsulados
    
    private static int siguienteCodigo = 1001; // Esto es un contador para que no existan codigos repetidos
    
    private int codigo;
    private String producto;
    private String categoria; 
    private double precio;
    private int stock;
    
    public final int stockMinimo = 5; //publico al ser inalterable y comun a todos los repuestos
    
    // Constructor 
    public  Repuestos(String producto, String categoria, double precio, int stock) {
        this.codigo = siguienteCodigo++;
        this.producto = producto;
        this.categoria = categoria;
        setPrecio(precio);
        setStock(stock);
    }
    public  Repuestos(String producto, double precio, int stock) {
        this.codigo = siguienteCodigo++;
        this.producto = producto;
        this.categoria = "Miscelaneo";
        setPrecio(precio);
        setStock(stock);
    }

    // Métodos Getters para consultar estados
    public int getCodigo() {
        return this.codigo;
    }
    
    public String getProducto() {
        return producto;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public double getPrecio() {
        return this.precio;
    }

    public int getStock() {
        return this.stock;
    }
    
    public int getStockMinimo() {
        return stockMinimo;
    }

    
    // Métodos Setters con validaciones para que no existan problemas con introducir valores nada que ver al programa y salte error por consiguiente
    public void setPrecio(double precio) {
        if (precio >= 0) {
            this.precio = precio;
        } else {
            System.out.println("Error: Precio invalido.");
        }
    }

    public void setStock(int stock) {
        if (stock >= 0) {
            this.stock = stock;
        } else {
            System.out.println("Error: Stock invalido");
        }
    }
    
    public boolean ingresarStock(int cantidad){
        if (cantidad  > 0 && cantidad <= Integer.MAX_VALUE - stock){
            this.stock = stock + cantidad;
            return true;
        }
        return false;
    }
    
    public boolean retirarStock(int cantidad){
        if (cantidad > 0 && cantidad <= stock) {
            this.stock = stock - cantidad;
        }
        return false;
    } 
    
    public abstract String getTipo();

    // Método para mostrar por pantalla la información del repuesto (codigo, categoria, precio y stock en existencia)
    public void mostrarInfo() {
        System.out.println("Código: " + this.codigo + " | Nombre: " + this.producto + " | Categoría: " + this.categoria + " | Precio: $" + this.precio + " | Stock: " + this.stock);
    }
}
